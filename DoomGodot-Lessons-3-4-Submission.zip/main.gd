extends Node3D

# An original training base that borrows E1M1's teaching rhythm, not its map.
signal health_changed(new_health: int)
signal door_unlocked
signal level_completed

const FIREBALL_SCENE: PackedScene = preload("res://fireball.tscn")
const CELL: float = 3.0
const WALL_H: float = 3.2
const MAP: Array[String] = [
	"#####################",
	"#...........#.......#",
	"#...........#.......#",
	"#....#......#..###..#",
	"#....#......#.......#",
	"#...........#.......#",
	"#...........#.......#",
	"#...........#.......#",
	"#....#......#.......#",
	"#...........#.......#",
	"#...........#.......#",
	"#..P.......S.D....EX#",
	"#####################"
]

var player: CharacterBody3D
var camera: Camera3D
var stat_values: Array[Label] = []
var prompt_label: Label
var weapon: Control
var flash: ColorRect
var health: int = 100
var armor: int = 0
var ammo: int = 50
var enemies: Array[CharacterBody3D] = []
var door_node: Node3D
var door_open: bool = false
var exit_unlocked: bool = false
var won: bool = false
var shot_cooldown: float = 0.0
var flash_time: float = 0.0
var recoil_time: float = 0.0
var bob_time: float = 0.0
var map_origin := Vector3.ZERO

func _ready() -> void:
	_setup_input()
	_build_world()
	_build_player()
	_build_hud()
	health_changed.connect(_on_health_changed)
	door_unlocked.connect(_on_door_unlocked)
	level_completed.connect(_on_level_completed)
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _setup_input() -> void:
	_add_key("move_forward", KEY_W)
	_add_key("move_forward", KEY_UP)
	_add_key("move_back", KEY_S)
	_add_key("move_back", KEY_DOWN)
	_add_key("move_left", KEY_A)
	_add_key("move_right", KEY_D)
	_add_key("fire", KEY_CTRL)
	_add_key("fire", KEY_SPACE)
	_add_key("interact", KEY_E)
	_add_key("walk", KEY_SHIFT)

func _add_key(action: String, code: Key) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	var event := InputEventKey.new()
	event.physical_keycode = code
	InputMap.action_add_event(action, event)

func _cell_pos(col: int, row: int) -> Vector3:
	return map_origin + Vector3((col - 10) * CELL, 0, (row - 6) * CELL)

func _build_world() -> void:
	var world := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_COLOR
	environment.background_color = Color(0.035, 0.045, 0.045)
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color(0.62, 0.70, 0.66)
	environment.ambient_light_energy = 0.85
	world.environment = environment
	add_child(world)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55, -25, 0)
	sun.light_color = Color(0.73, 0.82, 0.76)
	sun.light_energy = 0.35
	add_child(sun)

	var floor_mat := _mat(Color(0.22, 0.24, 0.22))
	var ceiling_mat := _mat(Color(0.11, 0.14, 0.13))
	_box("Base floor", Vector3(0, -0.18, 0), Vector3(66, 0.36, 42), floor_mat, true)
	_box("Ceiling", Vector3(0, WALL_H + 0.14, 0), Vector3(66, 0.28, 42), ceiling_mat, false)

	for row in range(MAP.size()):
		for col in range(MAP[row].length()):
			var cell: String = MAP[row].substr(col, 1)
			var pos := _cell_pos(col, row)
			if cell != "#":
				var tile_color := Color(0.20, 0.22, 0.21) if (row + col) % 2 == 0 else Color(0.24, 0.25, 0.23)
				_box("Floor panel", pos + Vector3(0, 0.02, 0), Vector3(CELL - 0.05, 0.04, CELL - 0.05), _mat(tile_color), false)
			if cell == "#":
				var shade := 0.9 + float((row * 7 + col * 3) % 5) * 0.035
				_box("Concrete wall", pos + Vector3(0, WALL_H / 2.0, 0), Vector3(CELL, WALL_H, CELL), _mat(Color(0.31, 0.36, 0.33) * shade), true)
			elif cell == "P":
				_spawn_player_marker(pos)
			elif cell == "S":
				_add_switch(pos)
			elif cell == "D":
				_add_door(pos)
			elif cell == "E":
				_spawn_enemy(pos)
			elif cell == "X":
				_add_exit(pos)

	_add_start_room_details()
	_add_training_features()
	_add_lights()

func _add_start_room_details() -> void:
	var bay_center := _cell_pos(5, 11)
	for x_offset in [-6.0, 6.0]:
		for z_offset in [-2.0, 2.0]:
			_box("Steel support", bay_center + Vector3(x_offset, 1.6, z_offset), Vector3(0.7, 3.2, 0.7), _mat(Color(0.24, 0.32, 0.30)), true)
	_box("Dropped equipment case", bay_center + Vector3(2.0, 0.35, 1.4), Vector3(0.85, 0.7, 1.15), _mat(Color(0.38, 0.30, 0.18)), true)
	_box("Warning panel", bay_center + Vector3(2.0, 1.5, 2.1), Vector3(0.5, 0.5, 0.12), _mat(Color(0.72, 0.08, 0.035), true), false)

func _add_training_features() -> void:
	# A shallow overlook gives the first enemy a readable silhouette above the route.
	var ledge_pos := _cell_pos(16, 4)
	_box("Raised overlook", ledge_pos + Vector3(0, 0.45, 0), Vector3(3.0, 0.9, 3.0), _mat(Color(0.25, 0.31, 0.29)), true)
	for i in range(3):
		var step_pos := _cell_pos(13 + i, 4)
		var rise := 0.18 * float(i + 1)
		_box("Overlook step", step_pos + Vector3(0, rise / 2.0, 0), Vector3(2.7, rise, 2.2), _mat(Color(0.28, 0.33, 0.30)), true)
	# Small colored wall panels communicate the old industrial science-fiction setting.
	for row in [2, 8]:
		var panel_pos := _cell_pos(0, row) + Vector3(1.5, 1.9, 0)
		_box("Green status panel", panel_pos, Vector3(0.08, 0.48, 1.1), _mat(Color(0.18, 0.72, 0.38), true), false)

func _add_lights() -> void:
	_add_lamp(_cell_pos(4, 10), Color(0.86, 0.62, 0.34), 1.6)
	_add_lamp(_cell_pos(8, 6), Color(0.35, 0.70, 0.55), 1.4)
	_add_lamp(_cell_pos(15, 6), Color(0.70, 0.32, 0.18), 1.0)
	_add_lamp(_cell_pos(17, 10), Color(0.75, 0.55, 0.27), 1.5)

func _add_lamp(pos: Vector3, tint: Color, energy: float) -> void:
	_box("Ceiling lamp", pos + Vector3(0, WALL_H - 0.08, 0), Vector3(1.0, 0.12, 0.65), _mat(tint, true), false)
	var light := OmniLight3D.new()
	light.position = pos + Vector3(0, WALL_H - 0.35, 0)
	light.light_color = tint
	light.light_energy = energy
	light.omni_range = 8.0
	add_child(light)

func _spawn_player_marker(pos: Vector3) -> void:
	player = CharacterBody3D.new()
	player.name = "Marine"
	player.add_to_group("player")
	player.position = pos + Vector3(0, 0.06, 0)
	player.floor_snap_length = 0.3
	add_child(player)
	var shape := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.34
	capsule.height = 1.45
	shape.shape = capsule
	shape.position.y = 0.72
	player.add_child(shape)
	camera = Camera3D.new()
	camera.position.y = 1.26
	camera.fov = 78
	player.add_child(camera)
	camera.current = true

func _build_player() -> void:
	if player == null:
		push_error("Map has no P player start tile")

func _build_hud() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var top := Label.new()
	top.text = "PHOBOS STATION  //  ENTRY BAY 01"
	top.position = Vector2(8, 3)
	top.add_theme_color_override("font_color", Color(0.8, 0.72, 0.48))
	top.add_theme_font_size_override("font_size", 9)
	layer.add_child(top)
	var help := Label.new()
	help.text = "WASD MOVE  MOUSE LOOK  CLICK FIRE  E USE  SHIFT WALK"
	help.position = Vector2(8, 15)
	help.add_theme_font_size_override("font_size", 8)
	help.add_theme_color_override("font_color", Color(0.78, 0.82, 0.73))
	layer.add_child(help)
	prompt_label = Label.new()
	prompt_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	prompt_label.position = Vector2(-115, -91)
	prompt_label.add_theme_color_override("font_color", Color(1.0, 0.82, 0.4))
	prompt_label.add_theme_font_size_override("font_size", 9)
	layer.add_child(prompt_label)
	var crosshair := Label.new()
	crosshair.text = "+"
	crosshair.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	crosshair.position = Vector2(-7, -15)
	crosshair.add_theme_color_override("font_color", Color(1.0, 0.86, 0.62))
	crosshair.add_theme_font_size_override("font_size", 12)
	layer.add_child(crosshair)
	var bar := ColorRect.new()
	bar.color = Color(0.045, 0.055, 0.05)
	bar.anchor_left = 0.0
	bar.anchor_right = 1.0
	bar.anchor_top = 1.0
	bar.anchor_bottom = 1.0
	bar.offset_top = -38
	layer.add_child(bar)
	var stat_names := ["HEALTH", "ARMOR", "AMMO"]
	for i in range(stat_names.size()):
		var x_pos := 6.0 + float(i) * 103.0
		var name_label := Label.new()
		name_label.text = stat_names[i]
		name_label.position = Vector2(x_pos, 2)
		name_label.size = Vector2(96, 10)
		name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		name_label.add_theme_color_override("font_color", Color(0.75, 0.72, 0.60))
		name_label.add_theme_font_size_override("font_size", 8)
		bar.add_child(name_label)
		var value_label := Label.new()
		value_label.position = Vector2(x_pos, 15)
		value_label.size = Vector2(96, 17)
		value_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		value_label.add_theme_color_override("font_color", Color(0.85, 0.82, 0.68))
		value_label.add_theme_font_size_override("font_size", 12)
		bar.add_child(value_label)
		stat_values.append(value_label)
	_refresh_hud()
	weapon = Control.new()
	weapon.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	weapon.position = Vector2(-24, -93)
	layer.add_child(weapon)
	var grip := ColorRect.new()
	grip.color = Color(0.26, 0.24, 0.20)
	grip.position = Vector2(7, 18)
	grip.size = Vector2(30, 34)
	weapon.add_child(grip)
	var gunmetal := ColorRect.new()
	gunmetal.color = Color(0.45, 0.44, 0.38)
	gunmetal.position = Vector2(12, 0)
	gunmetal.size = Vector2(20, 28)
	weapon.add_child(gunmetal)
	var barrel := ColorRect.new()
	barrel.color = Color(0.16, 0.17, 0.15)
	barrel.position = Vector2(15, 0)
	barrel.size = Vector2(14, 16)
	weapon.add_child(barrel)
	flash = ColorRect.new()
	flash.color = Color(1.0, 0.75, 0.25, 0.85)
	flash.position = Vector2(6, -16)
	flash.size = Vector2(34, 20)
	flash.visible = false
	weapon.add_child(flash)

func _refresh_hud() -> void:
	var values := [health, armor, ammo]
	for i in range(stat_values.size()):
		stat_values[i].text = "%03d" % values[i]

func _mat(color: Color, emissive: bool = false) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	if emissive:
		material.emission_enabled = true
		material.emission = color
		material.emission_energy_multiplier = 1.2
	return material

func _box(label: String, pos: Vector3, size: Vector3, material: Material, solid: bool) -> MeshInstance3D:
	var node := MeshInstance3D.new()
	node.name = label
	var mesh := BoxMesh.new()
	mesh.size = size
	node.mesh = mesh
	node.position = pos
	node.material_override = material
	add_child(node)
	if solid:
		var body := StaticBody3D.new()
		body.position = pos
		add_child(body)
		var collision := CollisionShape3D.new()
		var box := BoxShape3D.new()
		box.size = size
		collision.shape = box
		body.add_child(collision)
	return node

func _add_switch(pos: Vector3) -> void:
	_box("Door control pedestal", pos + Vector3(0, 0.55, 0), Vector3(0.65, 1.1, 0.65), _mat(Color(0.28, 0.31, 0.27)), true)
	_box("Door control", pos + Vector3(0, 1.15, -0.34), Vector3(0.38, 0.34, 0.08), _mat(Color(0.9, 0.28, 0.06), true), false)

func _add_door(pos: Vector3) -> void:
	door_node = Node3D.new()
	door_node.name = "Locked blast door"
	# The route is two cells deep at the doorway: cover the D tile and the open
	# tile immediately north of it so the player cannot slip around the panel.
	var door_center := pos + Vector3(0, 0, -CELL * 0.5)
	door_node.position = door_center
	add_child(door_node)
	var mesh_node := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	# A small overlap into the surrounding wall/floor prevents a narrow
	# walk-through seam at the edges of the doorway.
	var sealed_door_size := Vector3(0.65, WALL_H + 0.1, CELL * 2.0 + 0.8)
	mesh.size = sealed_door_size
	mesh_node.mesh = mesh
	mesh_node.position.y = WALL_H / 2.0
	mesh_node.material_override = _mat(Color(0.42, 0.31, 0.17))
	door_node.add_child(mesh_node)
	var body := StaticBody3D.new()
	door_node.add_child(body)
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = sealed_door_size
	collision.shape = shape
	collision.position.y = WALL_H / 2.0
	body.add_child(collision)

func _add_exit(pos: Vector3) -> void:
	_box("Exit console", pos + Vector3(0, 0.55, 0), Vector3(0.7, 1.1, 0.7), _mat(Color(0.24, 0.31, 0.28)), true)
	_box("Exit indicator", pos + Vector3(0, 1.2, -0.38), Vector3(0.4, 0.28, 0.08), _mat(Color(0.2, 0.85, 0.35), true), false)

func _spawn_enemy(pos: Vector3) -> void:
	var enemy := CharacterBody3D.new()
	enemy.name = "Imp"
	enemy.add_to_group("enemy")
	enemy.set_meta("hp", 2)
	enemy.set_meta("attack_cooldown", randf_range(0.4, 1.2))
	enemy.position = pos + Vector3(0, 0.06, 0)
	enemy.floor_snap_length = 0.25
	add_child(enemy)
	var shape := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.38
	capsule.height = 1.45
	shape.shape = capsule
	shape.position.y = 0.72
	enemy.add_child(shape)
	var sprite := Sprite3D.new()
	sprite.name = "Camera-facing pixel sprite"
	sprite.texture = _make_enemy_texture()
	sprite.billboard = BaseMaterial3D.BILLBOARD_FIXED_Y
	sprite.pixel_size = 0.04
	sprite.position.y = 0.98
	sprite.shaded = false
	sprite.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	sprite.alpha_cut = SpriteBase3D.ALPHA_CUT_DISCARD
	enemy.add_child(sprite)
	enemies.append(enemy)

func _make_enemy_texture() -> ImageTexture:
	var image := Image.create(32, 48, false, Image.FORMAT_RGBA8)
	image.fill(Color(0, 0, 0, 0))
	var outline := Color(0.055, 0.065, 0.06)
	var armor_color := Color(0.42, 0.16, 0.10)
	var armor_light := Color(0.68, 0.30, 0.12)
	var skin := Color(0.72, 0.30, 0.18)
	_paint_ellipse(image, Vector2i(16, 11), Vector2i(7, 8), outline)
	_paint_ellipse(image, Vector2i(16, 11), Vector2i(5, 6), skin)
	_paint_ellipse(image, Vector2i(16, 27), Vector2i(10, 12), outline)
	_paint_ellipse(image, Vector2i(16, 27), Vector2i(8, 10), armor_color)
	_paint_ellipse(image, Vector2i(6, 27), Vector2i(4, 10), outline)
	_paint_ellipse(image, Vector2i(26, 27), Vector2i(4, 10), outline)
	_paint_ellipse(image, Vector2i(6, 27), Vector2i(2, 8), armor_color)
	_paint_ellipse(image, Vector2i(26, 27), Vector2i(2, 8), armor_color)
	for y in range(35, 47):
		for x in range(7, 15):
			image.set_pixel(x, y, outline)
			image.set_pixel(x + 10, y, outline)
	for y in range(36, 45):
		for x in range(9, 13):
			image.set_pixel(x, y, armor_color)
			image.set_pixel(x + 10, y, armor_color)
	for y in range(22, 30):
		image.set_pixel(16, y, armor_light)
	for x in [13, 19]:
		image.set_pixel(x, 11, Color(1.0, 0.16, 0.06))
		image.set_pixel(x, 12, Color(0.9, 0.12, 0.04))
	return ImageTexture.create_from_image(image)

func _paint_ellipse(image: Image, center: Vector2i, radii: Vector2i, color: Color) -> void:
	for y in range(center.y - radii.y, center.y + radii.y + 1):
		for x in range(center.x - radii.x, center.x + radii.x + 1):
			var dx := float(x - center.x) / float(radii.x)
			var dy := float(y - center.y) / float(radii.y)
			if dx * dx + dy * dy <= 1.0:
				image.set_pixel(x, y, color)

func _enemy_has_line_of_sight(enemy: CharacterBody3D) -> bool:
	var from := enemy.global_position + Vector3(0, 1.1, 0)
	var to := camera.global_position
	var query := PhysicsRayQueryParameters3D.create(from, to)
	query.exclude = [enemy.get_rid()]
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	return not hit.is_empty() and hit.get("collider") == player

func _spawn_enemy_fireball(enemy: CharacterBody3D) -> void:
	var fireball := FIREBALL_SCENE.instantiate() as Area3D
	if fireball == null:
		return
	fireball.name = "Imp fireball"
	fireball.connect("hit_player", Callable(self, "_on_fireball_hit_player"))
	add_child(fireball)
	var start := enemy.global_position + Vector3(0, 1.1, 0)
	var direction := (camera.global_position - start).normalized()
	fireball.global_position = start
	fireball.call("launch", direction)

func _on_fireball_hit_player(damage: int) -> void:
	health = maxi(0, health - damage)
	health_changed.emit(health)

func _on_health_changed(_new_health: int) -> void:
	_refresh_hud()

func _on_door_unlocked() -> void:
	if is_instance_valid(door_node):
		door_node.queue_free()

func _on_level_completed() -> void:
	won = true
	prompt_label.text = "AREA CLEAR — ESC TO RELEASE MOUSE"
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _unhandled_input(event: InputEvent) -> void:

	if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	if event is InputEventMouseButton and event.pressed:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
		if event.button_index == MOUSE_BUTTON_LEFT:
			_fire()
	if event.is_action_pressed("fire"):
		_fire()
	if event.is_action_pressed("interact"):
		_interact()
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED and not won:
		player.rotate_y(-event.relative.x * 0.0024)
		camera.rotate_x(-event.relative.y * 0.0024)
		camera.rotation.x = clamp(camera.rotation.x, deg_to_rad(-80), deg_to_rad(80))

func _physics_process(delta: float) -> void:
	shot_cooldown = maxf(0.0, shot_cooldown - delta)
	flash_time = maxf(0.0, flash_time - delta)
	recoil_time = maxf(0.0, recoil_time - delta)
	if flash and flash_time <= 0.0:
		flash.visible = false
	if weapon and recoil_time <= 0.0:
		weapon.position.y = -93.0
	if health <= 0 or won:
		return
	var move_input := Vector2(Input.get_action_strength("move_right") - Input.get_action_strength("move_left"), Input.get_action_strength("move_back") - Input.get_action_strength("move_forward")).normalized()
	var direction: Vector3 = (player.transform.basis * Vector3(move_input.x, 0, move_input.y)).normalized()
	var speed := 6.4 if Input.is_action_pressed("walk") else 9.0
	player.velocity.x = direction.x * speed
	player.velocity.z = direction.z * speed
	player.velocity.y -= 22.0 * delta
	player.move_and_slide()
	if direction.length() > 0.1:
		bob_time += delta * 10.0
		camera.position.y = 1.26 + sin(bob_time) * 0.025
	for enemy in enemies:
		if not is_instance_valid(enemy):
			continue
		var toward := player.global_position - enemy.global_position
		toward.y = 0
		var distance := toward.length()
		if distance > 1.8 and distance < 12.0:
			enemy.velocity.x = toward.normalized().x * 1.4
			enemy.velocity.z = toward.normalized().z * 1.4
			enemy.velocity.y -= 22.0 * delta
			enemy.move_and_slide()
		else:
			enemy.velocity = Vector3.ZERO
		var attack_cooldown := maxf(0.0, float(enemy.get_meta("attack_cooldown")) - delta)
		enemy.set_meta("attack_cooldown", attack_cooldown)
		if distance < 20.0 and attack_cooldown <= 0.0 and _enemy_has_line_of_sight(enemy):
			_spawn_enemy_fireball(enemy)
			enemy.set_meta("attack_cooldown", 1.6)
	_update_prompt()

func _update_prompt() -> void:
	var here := player.global_position
	if won:
		prompt_label.text = "AREA CLEAR — ESC TO RELEASE MOUSE"
	elif not door_open and door_node and here.distance_to(door_node.global_position) < 2.4:
		prompt_label.text = "BLAST DOOR LOCKED — USE CONTROL"
	elif not door_open and _distance_to_cell(11, 11) < 2.3:
		prompt_label.text = "E  ACTIVATE DOOR CONTROL"
	elif door_open and _distance_to_cell(19, 11) < 2.4:
		prompt_label.text = "E  USE EXIT CONSOLE"
	else:
		prompt_label.text = ""

func _distance_to_cell(col: int, row: int) -> float:
	return player.global_position.distance_to(_cell_pos(col, row) + Vector3(0, 0.8, 0))

func _interact() -> void:
	if not door_open and _distance_to_cell(11, 11) < 2.3:
		door_open = true
		door_unlocked.emit()
	elif door_open and _distance_to_cell(19, 11) < 2.4:
		level_completed.emit()

func _fire() -> void:
	if won or health <= 0 or ammo <= 0 or shot_cooldown > 0.0:
		return
	shot_cooldown = 0.28
	ammo -= 1
	flash.visible = true
	flash_time = 0.07
	recoil_time = 0.08
	weapon.position.y = -89.0
	var from := camera.global_position
	var to := from - camera.global_transform.basis.z * 40.0
	var query := PhysicsRayQueryParameters3D.create(from, to)
	query.exclude = [player.get_rid()]
	query.collide_with_bodies = true
	query.collide_with_areas = true
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	if not hit.is_empty():
		var target := hit.get("collider") as Node
		if target != null and target.is_in_group("enemy"):
			var hp: int = int(target.get_meta("hp", 1)) - 1
			target.set_meta("hp", hp)
			if hp <= 0:
				enemies.erase(target)
				target.queue_free()
	_refresh_hud()

func _exit_tree() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
